<?php

declare(strict_types=1);

namespace Tests\Feature\Security;

use App\Services\Analytics\DTOs\Contract3\ExecutionAuthorizationGrant;
use App\Services\Analytics\DTOs\Contract3\GrantSigner;
use App\Services\Analytics\DTOs\Contract3\PreparedQueryArtifact;
use App\Services\Spreadsheet\Relationships\DTOs\DiscoveredRelationshipEdge;
use App\Services\Spreadsheet\Relationships\DTOs\SpreadsheetRelationshipGraph;
use App\Services\Spreadsheet\Security\AnalyticsAstAuthorizer;
use App\Services\Spreadsheet\Security\DataClassification;
use App\Services\Spreadsheet\Security\Exceptions\UnauthorizedDataAccessException;
use App\Services\Spreadsheet\Security\ServerControlledContext;
use Tests\TestCase;

class AnalyticsAstAuthorizerContract3Test extends TestCase
{
    private AnalyticsAstAuthorizer $authorizer;
    private int $workspaceId = 99;
    private string $secretKey = 'test_secret_for_authorizer_test';

    protected function setUp(): void
    {
        parent::setUp();
        $this->authorizer = new AnalyticsAstAuthorizer();
    }

    private function createArtifact(
        string $sql,
        array $confirmedEdgeIds = [],
        int $workspaceId = 99,
        array $params = []
    ): PreparedQueryArtifact {
        return new PreparedQueryArtifact(
            contractVersion: '3.0.0',
            requestId: 'req_test_001',
            workspaceId: $workspaceId,
            datasetId: 'ds_test',
            generationId: 'gen_test_uuid',
            queryFingerprint: str_repeat('e', 64),
            schemaFingerprint: str_repeat('f', 64),
            sqlTemplate: $sql,
            params: $params,
            referencedTables: ['orders'],
            referencedColumns: ['amount'],
            confirmedEdgeIds: $confirmedEdgeIds,
        );
    }

    public function test_customer_channel_strictly_barred(): void
    {
        $context = ServerControlledContext::forCustomer($this->workspaceId);

        $artifact = $this->createArtifact('SELECT SUM(amount) FROM orders');

        $this->expectException(UnauthorizedDataAccessException::class);
        $this->expectExceptionMessage('Customer channels are strictly forbidden');

        $this->authorizer->authorizePreparedQuery(
            artifact: $artifact,
            sourceDescriptors: [],
            graph: null,
            context: $context,
            secretKey: $this->secretKey
        );
    }

    public function test_workspace_mismatch_rejected(): void
    {
        $context = new ServerControlledContext(
            workspaceId: 10, // Context workspace
            userId: 1,
            userRole: 'owner',
            channel: ServerControlledContext::CHANNEL_DASHBOARD,
            purpose: ServerControlledContext::PURPOSE_ANALYTICS_REPORTING
        );

        $artifact = $this->createArtifact('SELECT SUM(amount) FROM orders', confirmedEdgeIds: [], workspaceId: 20); // Different workspace

        $this->expectException(UnauthorizedDataAccessException::class);
        $this->expectExceptionMessage('Workspace mismatch');

        $this->authorizer->authorizePreparedQuery(
            artifact: $artifact,
            sourceDescriptors: [],
            graph: null,
            context: $context,
            secretKey: $this->secretKey
        );
    }

    public function test_mutating_sql_rejected(): void
    {
        $context = new ServerControlledContext(
            workspaceId: $this->workspaceId,
            userId: 1,
            userRole: 'owner',
            channel: ServerControlledContext::CHANNEL_DASHBOARD,
            purpose: ServerControlledContext::PURPOSE_ANALYTICS_REPORTING
        );

        $artifact = $this->createArtifact('DROP TABLE orders;');

        $this->expectException(UnauthorizedDataAccessException::class);
        $this->expectExceptionMessage('Mutating SQL keyword');

        $this->authorizer->authorizePreparedQuery(
            artifact: $artifact,
            sourceDescriptors: [],
            graph: null,
            context: $context,
            secretKey: $this->secretKey
        );
    }

    public function test_unconfirmed_relationship_edge_rejected(): void
    {
        $context = new ServerControlledContext(
            workspaceId: $this->workspaceId,
            userId: 1,
            userRole: 'owner',
            channel: ServerControlledContext::CHANNEL_DASHBOARD,
            purpose: ServerControlledContext::PURPOSE_ANALYTICS_REPORTING
        );

        // Edge in state DISCOVERED (not confirmed)
        $unconfirmedEdge = DiscoveredRelationshipEdge::fromArray([
            'id' => 'edge_unconfirmed_001',
            'source_sheet' => 'Orders',
            'source_column_ids' => ['col_cust_id'],
            'source_headers' => ['Customer ID'],
            'target_sheet' => 'Customers',
            'target_column_ids' => ['col_id'],
            'target_headers' => ['ID'],
            'state' => DiscoveredRelationshipEdge::STATE_DISCOVERED,
        ]);

        $graph = new SpreadsheetRelationshipGraph(
            workspaceId: $this->workspaceId,
            documentId: 'ds_test',
            jobId: null,
            generationId: 'gen_test_uuid',
            edges: [$unconfirmedEdge->id => $unconfirmedEdge]
        );

        $artifact = $this->createArtifact(
            sql: 'SELECT o.amount, c.name FROM orders o JOIN customers c ON o.cust_id = c.id',
            confirmedEdgeIds: ['edge_unconfirmed_001']
        );

        $this->expectException(UnauthorizedDataAccessException::class);
        $this->expectExceptionMessage('which is not confirmed');

        $this->authorizer->authorizePreparedQuery(
            artifact: $artifact,
            sourceDescriptors: [],
            graph: $graph,
            context: $context,
            secretKey: $this->secretKey
        );
    }

    public function test_confirmed_relationship_edge_authorized_and_grant_issued(): void
    {
        $context = new ServerControlledContext(
            workspaceId: $this->workspaceId,
            userId: 1,
            userRole: 'owner',
            channel: ServerControlledContext::CHANNEL_DASHBOARD,
            purpose: ServerControlledContext::PURPOSE_ANALYTICS_REPORTING
        );

        $confirmedEdge = DiscoveredRelationshipEdge::fromArray([
            'id' => 'edge_confirmed_001',
            'source_sheet' => 'Orders',
            'source_column_ids' => ['col_cust_id'],
            'source_headers' => ['Customer ID'],
            'target_sheet' => 'Customers',
            'target_column_ids' => ['col_id'],
            'target_headers' => ['ID'],
            'state' => DiscoveredRelationshipEdge::STATE_CONFIRMED,
        ]);

        $graph = new SpreadsheetRelationshipGraph(
            workspaceId: $this->workspaceId,
            documentId: 'ds_test',
            jobId: null,
            generationId: 'gen_test_uuid',
            edges: [$confirmedEdge->id => $confirmedEdge]
        );

        $artifact = $this->createArtifact(
            sql: 'SELECT o.amount, c.name FROM orders o JOIN customers c ON o.cust_id = c.id',
            confirmedEdgeIds: ['edge_confirmed_001']
        );

        $grant = $this->authorizer->authorizePreparedQuery(
            artifact: $artifact,
            sourceDescriptors: [],
            graph: $graph,
            context: $context,
            secretKey: $this->secretKey
        );

        $this->assertInstanceOf(ExecutionAuthorizationGrant::class, $grant);
        $this->assertSame($this->workspaceId, $grant->workspaceId);
        $this->assertSame($artifact->queryFingerprint, $grant->queryFingerprint);
        $this->assertSame($artifact->generationId, $grant->generationId);
        $this->assertTrue($grant->verifySignature($this->secretKey));
        $this->assertFalse($grant->isExpired());
    }

    public function test_non_owner_field_sensitivity_enforced(): void
    {
        $context = new ServerControlledContext(
            workspaceId: $this->workspaceId,
            userId: 5,
            userRole: 'agent',
            channel: ServerControlledContext::CHANNEL_DASHBOARD,
            purpose: ServerControlledContext::PURPOSE_ANALYTICS_REPORTING,
            grantedPermissions: [] // No special permissions
        );

        $sourceDescriptors = [
            'purchase_cost' => [
                'source_column_id' => 'purchase_cost',
                'original_header'  => 'Purchase Cost',
                'semantic_role'    => 'financial_metric',
                'sensitivity'      => DataClassification::RESTRICTED, // Restricted!
            ],
        ];

        $artifact = $this->createArtifact('SELECT purchase_cost FROM orders');

        $this->expectException(UnauthorizedDataAccessException::class);
        $this->expectExceptionMessage('Access denied: Query references unauthorized column');

        $this->authorizer->authorizePreparedQuery(
            artifact: $artifact,
            sourceDescriptors: $sourceDescriptors,
            graph: null,
            context: $context,
            secretKey: $this->secretKey
        );
    }
}
