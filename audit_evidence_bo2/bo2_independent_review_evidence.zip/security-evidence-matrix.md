# BO-2 Security & Architecture Claims Evidence Matrix
**Repository:** `multi-source-chatbot`  
**Parent Runtime:** BO-1 Shared Agent Runtime  
**Target Stage:** BO-2 Business Owner Intelligence Concrete Tools  
**Auditor Mode:** Independent Read-Only Review Evidence Package  
**Governance Authority:** DOC-23-CS-READY-DECISION-v1.1 §16

---

## Claims Verification Summary

| # | Security / Architecture Claim | Audit Status | Exact Test Reference | Assertion Line(s) | Source Code Line(s) |
|---|-------------------------------|:------------:|----------------------|-------------------|---------------------|
| 1 | Expired Excel grant rejection | **VERIFIED** (DTO) / **DELEGATED** | `tests/Unit/Analytics/Contract3DTOTest.php::test_execution_authorization_grant_expiry` | L128 (`assertTrue`), L141 (`assertFalse`) | `app/Services/Analytics/DTOs/Contract3/ExecutionAuthorizationGrant.php:57-67` |
| 2 | Single-use grant enforcement | **NOT TESTED** (in PHP) | *N/A (Delegated to Python Gateway)* | None in PHPUnit | `app/Services/Spreadsheet/Security/AnalyticsAstAuthorizer.php:194-201`, `app/Services/Analytics/DTOs/Contract3/GrantSigner.php:97` |
| 3 | Grant replay prevention | **VERIFIED** (HMAC) / **NOT TESTED** (Cache) | `tests/Feature/AI/Agent/BO2/OwnerBusinessAgentAuditTest.php::test_audit_13_ast_authorization_and_grant_signer_integration` | L777 (`assertFalse(verifySignature)`) | `app/Services/Analytics/DTOs/Contract3/GrantSigner.php:44-60`, `app/Services/Analytics/DTOs/Contract3/ExecutionAuthorizationGrant.php:41-52` |
| 4 | Cross-workspace grant rejection | **VERIFIED** | `tests/Feature/Security/AnalyticsAstAuthorizerContract3Test.php::test_workspace_mismatch_rejected` | L82-83 (`expectException: Workspace mismatch`) | `app/Services/Spreadsheet/Security/AnalyticsAstAuthorizer.php:143-148` |
| 5 | Query artifact binding | **VERIFIED** | `tests/Feature/Security/AnalyticsAstAuthorizerContract3Test.php::test_confirmed_relationship_edge_authorized_and_grant_issued` | L208-211 (`assertSame(workspace, fingerprint, genId)`) | `app/Services/Spreadsheet/Security/AnalyticsAstAuthorizer.php:194-202`, `app/Services/Analytics/DTOs/Contract3/GrantSigner.php:21-39` |
| 6 | Unknown Excel column fail-closed behavior | **VERIFIED** (Restricted) / **NOT TESTED** (Unmapped) | `tests/Feature/Security/AnalyticsAstAuthorizerContract3Test.php::test_non_owner_field_sensitivity_enforced` | L237-238 (`expectException: unauthorized column`) | `app/Services/Spreadsheet/Security/AnalyticsAstAuthorizer.php:190-192, 351-384` |
| 7 | Direct legacy Excel endpoint prohibition | **VERIFIED** | `tests/Feature/AI/Agent/BO2/OwnerBusinessAgentAuditTest.php::test_audit_14_direct_excel_query_prohibition` | L795-797 (`assertContains(AnalyticsClient, AstAuthorizer)`) | `app/Services/AI/Agent/Tools/LegacyExcelAnalyticsTool.php:88-120` |
| 8 | Unauthorized financial field removed from structured data | **VERIFIED** | `tests/Feature/AI/Agent/BO2/OwnerBusinessAgentAuditTest.php::test_audit_04_dlp_field_filtering_projection_policy` | L400-402 (`assertArrayNotHasKey(cogs, gross_margin)`) | `app/Services/AI/Agent/Policies/ToolAuthorizationPolicy.php:280-330` |
| 9 | Unauthorized financial field absent from narrative and metadata | **VERIFIED** | `tests/Feature/AI/Agent/BO2/OwnerBusinessAgentAuditTest.php::test_audit_18_narrative_dlp_compliance_dec_bo1_08` | L931-932 (`assertStringNotContainsString('350')`) | `app/Services/AI/Agent/Policies/ToolAuthorizationPolicy.php:240-278, 480-520` |
| 10 | Restricted data absent from intermediate LLM context | **VERIFIED** | `tests/Unit/AI/Agent/AbstractGovernedToolTest.php::test_handle_automatically_projects_and_redacts_cost_price_for_staff` | L201-204 (`assertArrayNotHasKey(cost_price)`, `assertStringNotContainsString`) | `app/Services/AI/Agent/Tools/AbstractGovernedTool.php:70-85` |
| 11 | Knowledge document authorization and workspace isolation | **VERIFIED** | `tests/Unit/AI/Agent/Tools/KnowledgeAndExcelToolsTest.php::test_knowledge_intelligence_tool_contracts_and_faq_search` | L131 (`assertCount(1)` for staff), L149 (`assertCount(2)` for owner) | `app/Services/AI/Agent/Tools/KnowledgeIntelligenceTool.php:102-128` |
| 12 | Retrieval timeout versus genuine empty-result behavior | **VERIFIED** (Resilience) / **NOT DIFFERENTIATED IN PAYLOAD** | `tests/Feature/AI/Agent/BO2/OwnerBusinessAgentAuditTest.php::test_audit_11_downstream_retrieval_resiliency_in_knowledge_tool` vs `test_audit_09` | L666 (`assertTrue(success)`), L669 (`assertSame(0, match_count)`) | `app/Services/AI/Agent/Tools/KnowledgeIntelligenceTool.php:87-100` |
| 13 | Actual concurrent singleton/request-context isolation | **VERIFIED** (Sequential) / **NOT TESTED** (Multi-Threaded) | `tests/Feature/AI/Agent/BO2/OwnerBusinessAgentAuditTest.php::test_audit_15_singleton_statelessness_and_multi_user_concurrency` | L804 (`assertSame`), L827-846 (`assertFalse(hasCurrent)`, `$500` vs `$2000`) | `app/Services/AI/Agent/OwnerBusinessAgent.php:47`, `app/Services/AI/Agent/DTOs/AgentContext.php:121-137` |
| 14 | 4.0s deadline propagation across multiple sequential tools | **VERIFIED** (Clock/Agent) / **NOT TESTED** (Multi-Tool Chain) | `tests/Feature/AI/Agent/AgentRuntimeEngineTest.php::test_run_propagates_remaining_sla_timeout_to_native_agent` | L238-239 (`assertLessThanOrEqual(4.0)`, `assertGreaterThan(0.0)`) | `app/Services/AI/Agent/AgentRuntimeEngine.php:78, 132`, `app/Services/AI/Agent/DTOs/AgentContext.php:240-274` |
| 15 | Untrusted workspace ID spoofing rejection | **VERIFIED** | `tests/Feature/AI/Agent/BO2/OwnerBusinessAgentAuditTest.php::test_audit_03_llm_parameter_spoofing_resistance` | L318-321 (`assertSame(1000)`, `assertNotSame(99999)`) | `app/Services/AI/Agent/Tools/BusinessOverviewTool.php:72` |

---

## Detailed Notes on Non-Verified or Delegated Claims

### Claim 1 & 2: Single-Use Grant Enforcement & Replay Cache
- **Architecture Role:** In the Contract 3.0 virtual execution architecture, Laravel acts as Stage B (AST Authorizer and Grant Signer), while the Python analytics gateway acts as Stage C (Virtual SQLite execution).
- **Laravel Role:** Laravel generates cryptographically unique, unforgeable HMAC tokens containing a 16-byte random hex nonce (`GrantSigner::issue()`).
- **Python Gateway Role:** The consumption tracking (marking a nonce as consumed in Redis or in-memory LRU) occurs inside Python's `execution_gateway.py`.
- **Audit Assessment:** Single-use nonce emission and cryptographic signing are 100% verified in Laravel PHPUnit. Replay cache rejection of a consumed nonce is delegated to the Python gateway service.

### Claim 6: Unknown Column Fail-Closed Behavior
- **Architecture Role:** If a query explicitly references a column configured with `DataClassification::RESTRICTED`, `AnalyticsAstAuthorizer` throws `UnauthorizedDataAccessException` (verified in `AnalyticsAstAuthorizerContract3Test:215-247`).
- **Audit Assessment:** If a column name is completely unmapped and non-sensitive (e.g. `xyz_unmapped`), it is not rejected by `AnalyticsAstAuthorizer` prior to compilation; it fails at runtime when SQLite compiles the query against the schema. Therefore, generic unmapped column rejection is NOT TESTED at the authorizer level.

### Claim 12: Retrieval Timeout vs Genuine Empty Result
- **Architecture Role:** When Typesense or `RetrievalClient` throws an exception, `KnowledgeIntelligenceTool` catches `\Throwable`, logs a warning, and returns `match_count => 0` and empty `evidence_items` to protect user turn availability.
- **Audit Assessment:** Both timeout and genuine empty search return `success => true` and `match_count => 0`. The caller payload does not contain a machine-readable `downstream_degraded: true` flag.

### Claim 13: Concurrency Isolation
- **Architecture Role:** `OwnerBusinessAgent` is registered as a singleton in `AppServiceProvider`. It holds no mutable request state. `AgentContext` is managed ambiently via `try/finally` in `AgentContext::withContext()` and cleared in `app()->terminate()`.
- **Audit Assessment:** Sequential multi-user and multi-workspace execution across the singleton is 100% verified. Real multi-threaded race conditions (e.g., Swoole / FrankenPHP parallel workers) are NOT TESTED in standard single-threaded PHPUnit.
