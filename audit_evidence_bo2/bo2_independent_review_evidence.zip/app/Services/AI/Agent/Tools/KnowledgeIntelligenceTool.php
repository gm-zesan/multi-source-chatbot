<?php

declare(strict_types=1);

namespace App\Services\AI\Agent\Tools;

use App\Enums\Permissions\KnowledgeDocumentPermission;
use App\Models\FAQ;
use App\Services\AI\Agent\DTOs\AgentContext;
use App\Services\AI\Agent\DTOs\ToolResult;
use App\Services\AI\Agent\Exceptions\AgentExecutionTimeoutException;
use App\Services\Retrieval\RetrievalClient;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Facades\Log;
use Stringable;
use Throwable;

/**
 * KnowledgeIntelligenceTool (knowledge_intelligence).
 *
 * Governed business knowledge retrieval tool.
 * Performs semantic hybrid search across workspace FAQs and uploaded knowledge documents,
 * enforcing document-level permissions, tenant boundaries, and untrusted evidence guards.
 */
class KnowledgeIntelligenceTool extends AbstractGovernedTool
{
    public function __construct(
        private readonly ?RetrievalClient $retrievalClient = null,
    ) {}

    public function name(): string
    {
        return 'knowledge_intelligence';
    }

    public function description(): Stringable|string
    {
        return 'Searches business policies, operating procedures, product FAQs, and uploaded enterprise knowledge documents for factual evidence matching a query.';
    }

    public function isReadOnly(): bool
    {
        return true;
    }

    public function getRequiredPermissions(): array
    {
        return [];
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'query' => $schema->string()
                ->description('The natural language question, policy topic, or search query.')
                ->required(),
            'top_k' => $schema->integer()
                ->description('Maximum number of matching evidence items to retrieve (1-10). Defaults to 5.'),
        ];
    }

    public function execute(array $arguments, AgentContext $context): ToolResult
    {
        // 1. SLA Deadline Guard
        $remaining = $context->getRemainingSeconds();
        if ($remaining < 0.5) {
            throw new AgentExecutionTimeoutException(
                message: "Tool [{$this->name()}] execution aborted: remaining SLA budget ({$remaining}s) is below 0.5s threshold.",
                timeoutSeconds: $context->timeoutSeconds,
                elapsedSeconds: $context->timeoutSeconds - $remaining,
            );
        }

        $workspaceId = $context->getWorkspaceId();
        $query = trim((string) ($arguments['query'] ?? $arguments['question'] ?? ''));

        if ($query === '') {
            return ToolResult::failure('Query parameter cannot be empty.');
        }

        $topK = min(max(1, (int) ($arguments['top_k'] ?? 5)), 10);

        // 2. Resolve Retrieval Client
        $client = $this->retrievalClient ?? app(RetrievalClient::class);

        // 3. Execute Scoped Search with Downstream Resiliency
        try {
            $hits = $client->search(
                query: $query,
                workspaceId: $workspaceId,
                topK: $topK,
            );
        } catch (Throwable $e) {
            Log::warning("[{$this->name()}] Knowledge retrieval downstream failure", [
                'workspace_id' => $workspaceId,
                'query'        => $query,
                'error'        => $e->getMessage(),
            ]);
            $hits = [];
        }

        // 4. Verify Document-Level Authorization & Format Untrusted Evidence
        $canViewDocuments = $context->isOwner()
            || $context->hasPermission(KnowledgeDocumentPermission::VIEW->value)
            || $context->hasPermission('document.view');

        $evidenceList = [];

        foreach ($hits as $hit) {
            if (! $hit instanceof FAQ) {
                continue;
            }

            $docType = $hit->document_type ?? 'faq';

            // Document Chunk Access Control: Requires document.view
            if ($docType === 'knowledge_document' && ! $canViewDocuments) {
                continue;
            }

            $evidenceList[] = [
                'source_id'   => (string) $hit->id,
                'source_type' => $docType,
                'title'       => (string) ($hit->question ?? 'Knowledge Reference'),
                // Untrusted evidence quote
                'content'     => (string) ($hit->answer ?? ''),
            ];
        }

        return ToolResult::success([
            'query'          => $query,
            'match_count'    => count($evidenceList),
            'evidence_items' => $evidenceList,
        ], [
            'execution_time_ms' => $context->getElapsedMs(),
            'tool_name'         => $this->name(),
        ]);
    }
}

